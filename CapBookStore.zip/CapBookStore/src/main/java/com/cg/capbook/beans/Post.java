package com.cg.capbook.beans;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
@Entity
public class Post implements Comparable<Post>{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int postId;
	private String message;
	private LocalDate postDate;
	private LocalTime postTime;

	@ManyToOne(cascade=CascadeType.ALL)
	private Users user;

	@OneToOne(cascade=CascadeType.ALL,mappedBy="post")
	private Album album;

//		@ElementCollection
//		@JoinTable
//		private List<PostLike> postLikes;
		
	//	@ElementCollection
	//	@JoinTable
	//	private List<PostComment> postComments;

	public Post() {}	

	public Post(int postId, String message, LocalDate postDate, LocalTime postTime, Users user, Album album) {
		super();
		this.postId = postId;
		this.message = message;
		this.postDate = postDate;
		this.postTime = postTime;
		this.user = user;
		this.album = album;
	}

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public LocalDate getPostDate() {
		return postDate;
	}

	public void setPostDate(LocalDate postDate) {
		this.postDate = postDate;
	}

	public LocalTime getPostTime() {
		return postTime;
	}

	public void setPostTime(LocalTime postTime) {
		this.postTime = postTime;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public Album getAlbum() {
		return album;
	}

	public void setAlbum(Album album) {
		this.album = album;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((album == null) ? 0 : album.hashCode());
		result = prime * result + ((message == null) ? 0 : message.hashCode());
		result = prime * result + ((postDate == null) ? 0 : postDate.hashCode());
		result = prime * result + postId;
		result = prime * result + ((postTime == null) ? 0 : postTime.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Post other = (Post) obj;
		if (album == null) {
			if (other.album != null)
				return false;
		} else if (!album.equals(other.album))
			return false;
		if (message == null) {
			if (other.message != null)
				return false;
		} else if (!message.equals(other.message))
			return false;
		if (postDate == null) {
			if (other.postDate != null)
				return false;
		} else if (!postDate.equals(other.postDate))
			return false;
		if (postId != other.postId)
			return false;
		if (postTime == null) {
			if (other.postTime != null)
				return false;
		} else if (!postTime.equals(other.postTime))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Post [postId=" + postId + ", message=" + message + ", postDate=" + postDate + ", postTime=" + postTime
				+ ", user=" + user + ", album=" + album + "]";
	}

	@Override
	public int compareTo(Post p) {
		return this.postId - p.getPostId();
	}
}
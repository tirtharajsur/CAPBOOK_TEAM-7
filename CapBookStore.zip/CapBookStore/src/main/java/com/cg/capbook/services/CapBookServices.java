package com.cg.capbook.services;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.Users;
import com.cg.capbook.exceptions.EmailAlreadyExistException;
import com.cg.capbook.exceptions.PasswordMismatchException;
import com.cg.capbook.exceptions.SecurityAnswerMismatchException;
import com.cg.capbook.exceptions.SecurityQuestionMismatchException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;

public interface CapBookServices {
	Users acceptUserDetails(Users user) throws UserDetailsNotFoundException, EmailAlreadyExistException;
	Users getUserDetails(String emailId) throws UserDetailsNotFoundException;
	boolean deleteUserDetails(String emailId) throws UserDetailsNotFoundException;
	Users updateUserDetails(String emailId) throws UserDetailsNotFoundException;
	String encryptPassword(String password);
	String decryptPassword(String password);
	boolean changePassword(String emailId,String newPassword,String confirmPassword) throws UserDetailsNotFoundException,PasswordMismatchException;
	boolean forgetPassword(Users user) throws UserDetailsNotFoundException, SecurityAnswerMismatchException, SecurityQuestionMismatchException;
	Post savePost(Post post);
	List<Post> getAllPost();
	Post saveAlbumImages(String emailId,MultipartFile file) throws UserDetailsNotFoundException;
	//Customer saveProfilePicture(String emailId,MultipartFile File) throws CustomerDetailsNotFoundException;
}
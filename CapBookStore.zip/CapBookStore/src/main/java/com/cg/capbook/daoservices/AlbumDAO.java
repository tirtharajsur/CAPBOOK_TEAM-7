package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capbook.beans.Album;
import com.cg.capbook.beans.Users;

public interface AlbumDAO  extends JpaRepository<Album,Integer>{

}
